<template>
    <div>
        <p>demo2</p>
    </div>
</template>

<script>
    export default {
        name: "demo2"
    }
</script>

<style scoped>

</style>