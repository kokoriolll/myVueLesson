<template>
    <div>
        <p>One</p>
    </div>
</template>

<script>
    export default {
        name: "One"
    }
</script>

<style scoped>

</style>